#include <assert.h>

void check_values(float *ref, float *actual, int size) {
} 

void check_sequential_speedup(double speedup, int cl, int uf) {
}

void check_interleaved_speedup(double speedup, int cl, int uf) {
}
