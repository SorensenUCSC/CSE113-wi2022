#include <assert.h>

void check_values(double *ref, double *actual, int size) {
} 

void check_speedup(double speedup, int uf) {
}
