#include <assert.h>

void check_values(volatile int *arr, int size, int k) {
}

void check_round_robin_speedup(double speedup, int num_threads) {
}

void check_custom_speedup(double speedup, int num_threads) {
}

void check_custom_rr_speedup(double speedup, int num_threads) {
}

