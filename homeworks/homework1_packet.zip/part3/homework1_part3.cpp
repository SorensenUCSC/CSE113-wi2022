#include <iostream>
#include <assert.h>
#include <chrono>
#include "checker.h"
using namespace std;
using namespace std::chrono;

/** You may change these constants during development, but ensure that they are set to the initial values when submitting. */
#define SIZE 1024
#define K 1048576
#define NUM_THREADS 8

/** Write your sequential computation here. You may add arguments or change this signature as needed. */
void sequential_increment(volatile int *a, int size, int k) {
  // Implement me!
}

/** Write your round robin computation here. You may add arguments or change this signature as needed. */
void round_robin_increment(volatile int *b, int size, int k) {
  // Implement me!
}

/** Write your custom computation here. You may add arguments or change this signature as needed. */
void custom_increment(volatile int *c, int size, int k) {
}

int main() {
  volatile int a[SIZE] = {};
  volatile int b[SIZE] = {};
  volatile int c[SIZE] = {};

  auto seq_start = high_resolution_clock::now();
  // Implement me! You may add code here or in the function as needed.
  sequential_increment(a, SIZE, K);
  auto seq_stop = high_resolution_clock::now();
  auto seq_duration = duration_cast<nanoseconds>(seq_stop - seq_start);
  double seq_seconds = seq_duration.count()/1000000000.0;

  auto round_robin_start = high_resolution_clock::now();
  // Implement me! You may add code here or in the function as needed.
  round_robin_increment(b, SIZE, K);
  auto round_robin_stop = high_resolution_clock::now();
  auto round_robin_duration = duration_cast<nanoseconds>(round_robin_stop - round_robin_start);
  double round_robin_seconds = round_robin_duration.count()/1000000000.0;

  auto custom_start = high_resolution_clock::now();
  // Implement me! You may add code here or in the function as needed.
  custom_increment(c, SIZE, K);
  auto custom_stop = high_resolution_clock::now();
  auto custom_duration = duration_cast<nanoseconds>(custom_stop - custom_start);
  double custom_seconds = custom_duration.count()/1000000000.0;

  double round_robin_speedup = seq_seconds / round_robin_seconds;
  double custom_speedup = seq_seconds / custom_seconds;
  double custom_rr_speedup = round_robin_seconds / custom_seconds;

  // Do not remove
  check_values(a, SIZE, K);
  check_values(b, SIZE, K);
  check_values(c, SIZE, K);
  check_round_robin_speedup(round_robin_speedup, NUM_THREADS);
  check_custom_speedup(custom_speedup, NUM_THREADS);
  check_custom_rr_speedup(custom_rr_speedup, NUM_THREADS);

  return 0;
}


