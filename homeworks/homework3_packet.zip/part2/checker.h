enum ScheduleType { static_t, global_t, local_t,  local_32_t };

void check_results(float *result, int size, ScheduleType t) {

}

void check_timing(double seconds, ScheduleType t) {

}
