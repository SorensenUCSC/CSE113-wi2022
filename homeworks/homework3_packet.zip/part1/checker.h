#include <math.h>

#define SIZE (1024 * 1024 * 8)

enum QueueType { sync, async, eight, eight_chunked };

void check_results(float *a, int size, QueueType t) {

}

void check_timing(double seconds, QueueType t) {

}
