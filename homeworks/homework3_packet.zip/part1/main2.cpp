#include <math.h>
#include <thread>
#include <iostream>
#include <chrono>
#include "checker.h"

#include "CQueue.h"
CQueue memory_to_trig;
CQueue trig_to_memory;
QueueType t = eight_chunked;

void memory_load_thread_func(float *a, int size) {

  for (int i = 0; i < size; i++) {
    // Implement me!
  }
}

void trig_thread_func(int size) {

  for (int i = 0; i < size; i++) {
    //Implement me!
  }
}

void memory_store_thread_func(float *a, int size) {

  for (int i = 0; i < size; i++) {
    // Implement me!
  }
}

int main() {
  float *a = new float[SIZE];
  for (int i = 0; i < SIZE; i++) {
    a[i] = 0.5 + i;
  }
  auto start = std::chrono::high_resolution_clock::now();

  std::thread memory_load_thread(memory_load_thread_func,a,SIZE);
  std::thread trig_thread(trig_thread_func, SIZE);
  std::thread memory_store_thread(memory_store_thread_func,a,SIZE);

  memory_load_thread.join();
  trig_thread.join();
  memory_store_thread.join();

  auto stop = std::chrono::high_resolution_clock::now();
  auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(stop - start);
  double seconds = duration.count()/1000000000.0;
  check_results(a, SIZE, t);
  check_timing(seconds, t);

  std::cout << "time (seconds): " << seconds << std::endl;
 
  return 0;
}
