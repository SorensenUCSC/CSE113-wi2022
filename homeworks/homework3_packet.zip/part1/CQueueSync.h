#include <atomic>

class CQueue {
 public:

  CQueue() {
    // Implement me!
  }

  void enq(float e) {
    // Implement me!
  }

  float deq() {
    // Implement me!
    return 0.0;
  }
  
 private:
  // Give me some private variables 
};
