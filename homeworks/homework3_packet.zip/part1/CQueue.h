#include <atomic>

#define CQUEUE_SIZE 2048

class CQueue {
 public:

  CQueue() {
    // Implement me!
  }

  void enq(float e) {
    // Implement me!
  }

  void enq_8(float e[8]) {
    // Implement me for part 4
  }


  float deq() {
    // Implement me!
    return 0.0;
  }

  void deq_8(float e[8]) {
    // Implement me for part 4
  }


  int size() {
    // Implement me!
    return 0;
  }
  
 private:
  // give me some variables!
};
