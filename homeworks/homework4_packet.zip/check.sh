#!/bin/bash
if [ -d "$(pwd)/part1" ];
then
    (cd part1 && make)
else
    echo "part 1 directory does not exist"
    exit 1
fi

if [ -d "$(pwd)/part2" ];
then
    (cd part2 && make)
else
    echo "part 2 directory does not exist"
    exit 1
fi

if [ -d "$(pwd)/part3" ];
then
    (cd part3 && make)
else
    echo "part 3 directory does not exist"
    exit 1
fi
