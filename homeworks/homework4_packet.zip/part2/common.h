#define TEST_ITERATIONS (1024*256)

void check_output(int output0, int output1, int output2, int output3) {

}
