#include <random>
#define SIZE 1024 * 32
#define REPEATS (1024 * 8 + 1)
#define FMIN -100.0
#define FMAX 100.0
#define SEED 42

// From https://stackoverflow.com/questions/2704521/generate-random-double-numbers-in-c/9324796
double fRand()
{
    double f = (double)rand() / RAND_MAX;
    return FMIN + f * (FMAX - FMIN);
}

// By setting the seed of our random number generator, we can get reproducible results.
void set_random_seed() {
    srand(SEED);
}

void check_result(double* output, double time_seconds) {
}
