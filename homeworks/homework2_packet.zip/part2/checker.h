#include <assert.h>
#include <atomic>
using namespace std;

void check_throughput(const atomic_int& total_readers, const atomic_int& total_writers, bool is_fair_mutex) {
}
