#include <assert.h>
#include <atomic>
using namespace std;

enum ListType { coarse, rw, swaptop };

void check_pops(const atomic_int& pops, ListType t) {
}

void check_pushes(const atomic_int& pushes, ListType t) {
}

void check_peeks(const atomic_int& peeks, ListType t) {
}

void check_swaps(const atomic_int& swaps) {
}
