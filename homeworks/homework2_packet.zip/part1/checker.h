#include <assert.h>

enum MutexType { cpp, filter, bakery };

void check_distribution(int* histogram, MutexType t) {
}
